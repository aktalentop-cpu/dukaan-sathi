export type TxnType = 'sale' | 'expense';

export interface Transaction {
  id: string;
  type: TxnType;
  amount: number;
  date: string; // ISO yyyy-mm-dd
  note: string;
  createdAt: number;
}

export interface CreditEntry {
  id: string;
  customerId: string;
  amount: number; // positive = udhaar given (credit increases), negative = payment received
  date: string; // ISO yyyy-mm-dd
  note: string;
  createdAt: number;
}

export interface Customer {
  id: string;
  name: string;
  phone?: string;
  note?: string;
  createdAt: number;
}

export interface Product {
  id: string;
  name: string;
  purchasePrice: number;
  sellingPrice: number;
  quantity: number;
  lowStockThreshold: number;
  createdAt: number;
}

export interface AppData {
  customers: Customer[];
  credits: CreditEntry[];
  transactions: Transaction[];
  products: Product[];
  seeded: boolean;
}

export type Screen = 'dashboard' | 'udhaar' | 'sales' | 'stock' | 'reports';
