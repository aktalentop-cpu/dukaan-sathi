import { useMemo, useState } from 'react';
import { TrendingUp, TrendingDown, Wallet, Calendar, BarChart3, Receipt } from 'lucide-react';
import { useStore, totalOutstanding } from '@/lib/store';
import { formatPKR, formatDate, todayISO, isSameDay, isSameMonth } from '@/lib/format';
import { StatCard, EmptyState } from '@/components/UI';
import type { Screen } from '@/types';

type Period = 'day' | 'month';

export function ReportsScreen({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const { transactions, credits } = useStore();
  const [period, setPeriod] = useState<Period>('day');
  const today = todayISO();

  const isMatch = (d: string) => (period === 'day' ? isSameDay(d, today) : isSameMonth(d, today));

  const summary = useMemo(() => {
    const sales = transactions.filter((t) => t.type === 'sale' && isMatch(t.date));
    const expenses = transactions.filter((t) => t.type === 'expense' && isMatch(t.date));
    const totalSales = sales.reduce((s, t) => s + t.amount, 0);
    const totalExpenses = expenses.reduce((s, t) => s + t.amount, 0);
    return {
      totalSales,
      totalExpenses,
      profit: totalSales - totalExpenses,
      saleCount: sales.length,
      expenseCount: expenses.length,
      items: [...sales, ...expenses].sort((a, b) => b.createdAt - a.createdAt),
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [transactions, period, today]);

  const outstanding = useMemo(() => totalOutstanding(credits), [credits]);

  // Monthly chart data (last 6 months)
  const monthly = useMemo(() => {
    const months: { key: string; label: string; sales: number; expenses: number }[] = [];
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = d.toISOString().slice(0, 7);
      const label = d.toLocaleDateString('en-PK', { month: 'short' });
      const sales = transactions.filter((t) => t.type === 'sale' && t.date.slice(0, 7) === key).reduce((s, t) => s + t.amount, 0);
      const expenses = transactions.filter((t) => t.type === 'expense' && t.date.slice(0, 7) === key).reduce((s, t) => s + t.amount, 0);
      months.push({ key, label, sales, expenses });
    }
    return months;
  }, [transactions]);

  const maxMonthly = Math.max(1, ...monthly.map((m) => Math.max(m.sales, m.expenses)));

  return (
    <div className="px-4 pt-4 pb-4">
      <div className="mb-4">
        <h1 className="text-2xl font-extrabold text-slate-800">Reports</h1>
        <p className="text-sm text-slate-500">Sales, kharcha aur profit</p>
      </div>

      {/* Period toggle */}
      <div className="flex gap-2 mb-4 bg-slate-100 p-1 rounded-xl">
        <button
          onClick={() => setPeriod('day')}
          className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-colors ${period === 'day' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500'}`}
        >
          Aaj (Today)
        </button>
        <button
          onClick={() => setPeriod('month')}
          className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-colors ${period === 'month' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500'}`}
        >
          Is Mahine (Month)
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-3 mb-5">
        <StatCard label="Total Sale" value={formatPKR(summary.totalSales)} icon={TrendingUp} tone="emerald" sub={`${summary.saleCount} transactions`} />
        <StatCard label="Total Kharcha" value={formatPKR(summary.totalExpenses)} icon={TrendingDown} tone="red" sub={`${summary.expenseCount} transactions`} />
        <StatCard label="Est. Profit" value={formatPKR(summary.profit)} icon={Wallet} tone="blue" sub="Sale - Kharcha" />
        <StatCard label="Baqaya Udhaar" value={formatPKR(outstanding)} icon={Calendar} tone="amber" />
      </div>

      {/* Profit bar */}
      <div className={`rounded-2xl p-5 mb-5 text-white shadow-lg ${summary.profit >= 0 ? 'bg-gradient-to-br from-emerald-600 to-teal-700 shadow-emerald-600/20' : 'bg-gradient-to-br from-red-500 to-red-700 shadow-red-500/20'}`}>
        <p className="text-sm opacity-90">{period === 'day' ? "Aaj ka" : "Is mahine ka"} Estimated Profit</p>
        <p className="text-3xl font-extrabold mt-1">{formatPKR(summary.profit)}</p>
        <div className="mt-3 h-2 bg-white/20 rounded-full overflow-hidden">
          <div
            className="h-full bg-white/80 rounded-full transition-all"
            style={{ width: `${Math.min(100, (summary.totalSales / Math.max(1, summary.totalSales + summary.totalExpenses)) * 100)}%` }}
          />
        </div>
        <div className="flex justify-between mt-2 text-xs opacity-90">
          <span>Sale: {formatPKR(summary.totalSales)}</span>
          <span>Kharcha: {formatPKR(summary.totalExpenses)}</span>
        </div>
      </div>

      {/* 6-month mini chart */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-4 mb-5">
        <div className="flex items-center gap-2 mb-4">
          <BarChart3 size={16} className="text-slate-500" />
          <h2 className="font-bold text-slate-800 text-sm">6 Mahine ka Overview</h2>
        </div>
        <div className="flex items-end justify-between gap-2 h-32">
          {monthly.map((m) => (
            <div key={m.key} className="flex-1 flex flex-col items-center gap-1.5">
              <div className="w-full flex items-end justify-center gap-0.5 h-24">
                <div className="w-1/2 max-w-[14px] bg-emerald-500 rounded-t" style={{ height: `${(m.sales / maxMonthly) * 100}%` }} title={`Sales: ${formatPKR(m.sales)}`} />
                <div className="w-1/2 max-w-[14px] bg-red-400 rounded-t" style={{ height: `${(m.expenses / maxMonthly) * 100}%` }} title={`Kharcha: ${formatPKR(m.expenses)}`} />
              </div>
              <span className="text-[10px] font-semibold text-slate-400">{m.label}</span>
            </div>
          ))}
        </div>
        <div className="flex items-center gap-4 mt-3 pt-3 border-t border-slate-50 text-xs">
          <span className="flex items-center gap-1.5 text-slate-600"><span className="w-3 h-3 rounded bg-emerald-500" /> Sale</span>
          <span className="flex items-center gap-1.5 text-slate-600"><span className="w-3 h-3 rounded bg-red-400" /> Kharcha</span>
        </div>
      </div>

      {/* Period transactions */}
      <h2 className="font-bold text-slate-800 text-sm mb-3">
        {period === 'day' ? 'Aaj ki entries' : 'Is mahine ki entries'}
      </h2>
      {summary.items.length === 0 ? (
        <EmptyState icon={Receipt} title="Koi entry nahi" hint="Is period mein abhi koi transaction nahi" />
      ) : (
        <div className="space-y-2">
          {summary.items.map((t) => (
            <div key={t.id} className="bg-white rounded-xl border border-slate-100 shadow-sm p-3.5 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${t.type === 'sale' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                {t.type === 'sale' ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-700 truncate">{t.note || (t.type === 'sale' ? 'Sale' : 'Kharcha')}</p>
                <p className="text-xs text-slate-400">{formatDate(t.date)}</p>
              </div>
              <p className={`text-sm font-bold shrink-0 ${t.type === 'sale' ? 'text-emerald-600' : 'text-red-600'}`}>
                {t.type === 'sale' ? '+' : '-'}{formatPKR(t.amount)}
              </p>
            </div>
          ))}
        </div>
      )}

      <button onClick={() => onNavigate('sales')} className="mt-4 text-emerald-600 text-sm font-semibold w-full text-center">
        Sab transactions dekhein
      </button>
    </div>
  );
}
