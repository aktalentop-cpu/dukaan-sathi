import { useMemo, useState } from 'react';
import { Package, Plus, Pencil, Trash2, Minus, AlertTriangle, TrendingUp } from 'lucide-react';
import { useStore, type NewProductInput } from '@/lib/store';
import { formatPKR, formatNumber } from '@/lib/format';
import { Button, IconButton } from '@/components/Button';
import { Modal } from '@/components/Modal';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { SearchBar, AmountInput, TextField } from '@/components/Form';
import { EmptyState } from '@/components/UI';
import type { Product } from '@/types';

export function StockScreen() {
  const { products, addProduct, updateProduct, deleteProduct, adjustStock } = useStore();
  const [query, setQuery] = useState('');
  const [addOpen, setAddOpen] = useState(false);
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = q ? products.filter((p) => p.name.toLowerCase().includes(q)) : products;
    return list.slice().sort((a, b) => a.name.localeCompare(b.name));
  }, [products, query]);

  const totalItems = products.reduce((s, p) => s + p.quantity, 0);
  const lowCount = products.filter((p) => p.quantity <= p.lowStockThreshold).length;
  const stockValue = products.reduce((s, p) => s + p.purchasePrice * p.quantity, 0);

  return (
    <div className="px-4 pt-4 pb-4">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-800">Stock</h1>
          <p className="text-sm text-slate-500">Product manager</p>
        </div>
        <Button size="sm" onClick={() => setAddOpen(true)}>
          <Plus size={16} /> Product
        </Button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-3 text-center">
          <p className="text-lg font-extrabold text-slate-800">{formatNumber(totalItems)}</p>
          <p className="text-[11px] text-slate-400 font-medium">Total Items</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-3 text-center">
          <p className="text-lg font-extrabold text-emerald-600">{formatPKR(stockValue)}</p>
          <p className="text-[11px] text-slate-400 font-medium">Stock Value</p>
        </div>
        <div className={`rounded-xl border shadow-sm p-3 text-center ${lowCount > 0 ? 'bg-red-50 border-red-200' : 'bg-white border-slate-100'}`}>
          <p className={`text-lg font-extrabold ${lowCount > 0 ? 'text-red-600' : 'text-slate-800'}`}>{lowCount}</p>
          <p className="text-[11px] text-slate-400 font-medium">Low Stock</p>
        </div>
      </div>

      <div className="mb-4">
        <SearchBar value={query} onChange={setQuery} placeholder="Product search..." />
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={Package} title="Koi product nahi" hint="Naya product add karne ke liye button dabayein" />
      ) : (
        <div className="space-y-2.5">
          {filtered.map((p) => {
            const low = p.quantity <= p.lowStockThreshold;
            const margin = p.sellingPrice - p.purchasePrice;
            return (
              <div key={p.id} className="bg-white rounded-2xl border border-slate-100 shadow-sm p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-slate-800 truncate">{p.name}</p>
                    <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                      <span>Buy: <strong className="text-slate-700">{formatPKR(p.purchasePrice)}</strong></span>
                      <span>Sell: <strong className="text-slate-700">{formatPKR(p.sellingPrice)}</strong></span>
                      {margin > 0 && (
                        <span className="text-emerald-600 flex items-center gap-0.5">
                          <TrendingUp size={11} /> {formatPKR(margin)}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex shrink-0">
                    <IconButton onClick={() => setEditProduct(p)} className="!p-1.5 text-slate-300 hover:text-slate-600">
                      <Pencil size={14} />
                    </IconButton>
                    <IconButton onClick={() => setDeleteId(p.id)} className="!p-1.5 text-slate-300 hover:text-red-500">
                      <Trash2 size={14} />
                    </IconButton>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-50">
                  {/* Quantity controls */}
                  <div className="flex items-center gap-2">
                    <IconButton
                      onClick={() => adjustStock(p.id, -1)}
                      disabled={p.quantity === 0}
                      className="!p-1.5 bg-slate-100 !rounded-lg text-slate-600 hover:bg-slate-200"
                    >
                      <Minus size={15} />
                    </IconButton>
                    <span className={`min-w-[3.5rem] text-center font-bold ${low ? 'text-red-600' : 'text-slate-800'}`}>
                      {p.quantity}
                    </span>
                    <IconButton
                      onClick={() => adjustStock(p.id, 1)}
                      className="!p-1.5 bg-slate-100 !rounded-lg text-slate-600 hover:bg-slate-200"
                    >
                      <Plus size={15} />
                    </IconButton>
                  </div>
                  {low ? (
                    <span className="flex items-center gap-1 text-xs font-semibold text-red-600 bg-red-50 px-2 py-1 rounded-lg">
                      <AlertTriangle size={12} /> Low stock
                    </span>
                  ) : (
                    <span className="text-xs font-medium text-slate-400">in stock</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <ProductModal
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onSave={(input) => {
          addProduct(input);
          setAddOpen(false);
        }}
      />

      {editProduct && (
        <ProductModal
          open={!!editProduct}
          initial={editProduct}
          onClose={() => setEditProduct(null)}
          onSave={(input) => {
            updateProduct(editProduct.id, input);
            setEditProduct(null);
          }}
        />
      )}

      <ConfirmDialog
        open={!!deleteId}
        title="Product delete?"
        message="Yeh product stock se delete ho jayega. Continue?"
        confirmLabel="Delete"
        onConfirm={() => {
          if (deleteId) deleteProduct(deleteId);
          setDeleteId(null);
        }}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

function ProductModal({
  open,
  onClose,
  onSave,
  initial,
}: {
  open: boolean;
  onClose: () => void;
  onSave: (input: NewProductInput) => void;
  initial?: Product;
}) {
  const [name, setName] = useState(initial?.name ?? '');
  const [purchase, setPurchase] = useState(initial ? String(initial.purchasePrice) : '');
  const [selling, setSelling] = useState(initial ? String(initial.sellingPrice) : '');
  const [qty, setQty] = useState(initial ? String(initial.quantity) : '0');
  const [threshold, setThreshold] = useState(initial ? String(initial.lowStockThreshold) : '3');
  const [err, setErr] = useState('');

  const [openTracker, setOpenTracker] = useState(false);
  if (open !== openTracker) {
    setOpenTracker(open);
    if (open) {
      setName(initial?.name ?? '');
      setPurchase(initial ? String(initial.purchasePrice) : '');
      setSelling(initial ? String(initial.sellingPrice) : '');
      setQty(initial ? String(initial.quantity) : '0');
      setThreshold(initial ? String(initial.lowStockThreshold) : '3');
      setErr('');
    }
  }

  const submit = () => {
    if (!name.trim()) {
      setErr('Product ka naam likhein');
      return;
    }
    const pp = parseFloat(purchase);
    const sp = parseFloat(selling);
    const q = parseInt(qty, 10);
    const th = parseInt(threshold, 10);
    if (isNaN(pp) || pp < 0) return setErr('Sahi purchase price likhein');
    if (isNaN(sp) || sp < 0) return setErr('Sahi selling price likhein');
    if (isNaN(q) || q < 0) return setErr('Sahi quantity likhein');
    if (isNaN(th) || th < 0) return setErr('Sahi low-stock threshold likhein');
    onSave({
      name: name.trim(),
      purchasePrice: Math.round(pp * 100) / 100,
      sellingPrice: Math.round(sp * 100) / 100,
      quantity: q,
      lowStockThreshold: th,
    });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={initial ? 'Product Edit' : 'Naya Product'}
      footer={
        <div className="flex gap-3">
          <Button variant="secondary" block onClick={onClose}>
            Cancel
          </Button>
          <Button block onClick={submit}>
            Save
          </Button>
        </div>
      }
    >
      <div className="space-y-4">
        {err && <p className="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">{err}</p>}
        <TextField value={name} onChange={(v) => { setName(v); setErr(''); }} label="Product Naam" placeholder="Ataa, Cheeni, etc." autoFocus />
        <div className="grid grid-cols-2 gap-3">
          <AmountInput value={purchase} onChange={(v) => { setPurchase(v); setErr(''); }} label="Purchase Price" />
          <AmountInput value={selling} onChange={(v) => { setSelling(v); setErr(''); }} label="Selling Price" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <label className="block">
            <span className="block text-sm font-semibold text-slate-700 mb-1.5">Quantity</span>
            <input
              type="number"
              min="0"
              step="1"
              value={qty}
              onChange={(e) => { setQty(e.target.value); setErr(''); }}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            />
          </label>
          <label className="block">
            <span className="block text-sm font-semibold text-slate-700 mb-1.5">Low Stock Alert</span>
            <input
              type="number"
              min="0"
              step="1"
              value={threshold}
              onChange={(e) => { setThreshold(e.target.value); setErr(''); }}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            />
          </label>
        </div>
      </div>
    </Modal>
  );
}
