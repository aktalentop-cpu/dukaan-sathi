import { useMemo, useState } from 'react';
import { Users, Plus, Phone, ChevronRight, UserPlus, Pencil, Trash2, ArrowLeft, TrendingUp, TrendingDown } from 'lucide-react';
import { useStore, customerBalance, totalOutstanding } from '@/lib/store';
import { formatPKR, formatDate, todayISO } from '@/lib/format';
import { Button, IconButton } from '@/components/Button';
import { Modal } from '@/components/Modal';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { SearchBar, AmountInput, TextField, DateField, validateAmount } from '@/components/Form';
import { EmptyState, StatCard } from '@/components/UI';
import type { Customer } from '@/types';

export function UdhaarScreen() {
  const { customers, credits, addCustomer, updateCustomer, deleteCustomer, addCredit, deleteCredit } = useStore();
  const [query, setQuery] = useState('');
  const [addOpen, setAddOpen] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = q ? customers.filter((c) => c.name.toLowerCase().includes(q) || (c.phone ?? '').includes(q)) : customers;
    return list
      .map((c) => ({ customer: c, balance: customerBalance(credits, c.id) }))
      .sort((a, b) => b.balance - a.balance);
  }, [customers, credits, query]);

  const outstanding = useMemo(() => totalOutstanding(credits), [credits]);

  const selectedCustomer = selected ? customers.find((c) => c.id === selected) ?? null : null;

  if (selectedCustomer) {
    return (
      <CustomerDetail
        customer={selectedCustomer}
        onBack={() => setSelected(null)}
        onAddCredit={addCredit}
        onDeleteCredit={deleteCredit}
        onEditCustomer={(id, name, phone, note) => updateCustomer(id, name, phone, note)}
        onDeleteCustomer={(id) => {
          deleteCustomer(id);
          setSelected(null);
        }}
        credits={credits}
      />
    );
  }

  return (
    <div className="px-4 pt-4 pb-4">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-800">Udhaar Register</h1>
          <p className="text-sm text-slate-500">Customer ki baqaya raqam</p>
        </div>
        <Button size="sm" onClick={() => setAddOpen(true)}>
          <UserPlus size={16} /> Customer
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-3 mb-4">
        <StatCard label="Total Baqaya Udhaar" value={formatPKR(outstanding)} icon={Users} tone="amber" sub={`${customers.length} customers`} />
      </div>

      <div className="mb-4">
        <SearchBar value={query} onChange={setQuery} placeholder="Customer search karein..." />
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={Users} title="Koi customer nahi" hint="Naya customer add karne ke liye button dabayein" />
      ) : (
        <div className="space-y-2.5">
          {filtered.map(({ customer, balance }) => (
            <button
              key={customer.id}
              onClick={() => setSelected(customer.id)}
              className="w-full bg-white rounded-2xl border border-slate-100 shadow-sm p-4 flex items-center gap-3 active:scale-[0.98] transition-transform text-left"
            >
              <div className="w-11 h-11 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center font-bold shrink-0">
                {customer.name.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-slate-800 truncate">{customer.name}</p>
                {customer.phone && (
                  <p className="text-xs text-slate-400 flex items-center gap-1 truncate">
                    <Phone size={11} /> {customer.phone}
                  </p>
                )}
              </div>
              <div className="text-right shrink-0">
                <p className={`font-bold ${balance > 0 ? 'text-amber-600' : balance < 0 ? 'text-emerald-600' : 'text-slate-400'}`}>
                  {formatPKR(balance)}
                </p>
                <p className="text-[11px] text-slate-400">{balance > 0 ? 'Baqaya' : balance < 0 ? 'Aagey' : 'Clear'}</p>
              </div>
              <ChevronRight size={18} className="text-slate-300 shrink-0" />
            </button>
          ))}
        </div>
      )}

      <AddCustomerModal
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onSave={(name, phone, note) => {
          addCustomer(name, phone, note);
          setAddOpen(false);
        }}
      />
    </div>
  );
}

function AddCustomerModal({
  open,
  onClose,
  onSave,
  initial,
  title = 'Naya Customer',
}: {
  open: boolean;
  onClose: () => void;
  onSave: (name: string, phone?: string, note?: string) => void;
  initial?: Customer;
  title?: string;
}) {
  const [name, setName] = useState(initial?.name ?? '');
  const [phone, setPhone] = useState(initial?.phone ?? '');
  const [note, setNote] = useState(initial?.note ?? '');
  const [err, setErr] = useState('');

  // re-seed fields when modal opens
  const [wasOpen, setWasOpen] = useState(false);
  if (open !== wasOpen) {
    setWasOpen(open);
    if (open) {
      setName(initial?.name ?? '');
      setPhone(initial?.phone ?? '');
      setNote(initial?.note ?? '');
      setErr('');
    }
  }

  const submit = () => {
    if (!name.trim()) {
      setErr('Naam likhna zaroori hai');
      return;
    }
    onSave(name, phone, note);
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      footer={
        <div className="flex gap-3">
          <Button variant="secondary" block onClick={onClose}>
            Cancel
          </Button>
          <Button block onClick={submit}>
            Save
          </Button>
        </div>
      }
    >
      <div className="space-y-4">
        {err && <p className="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">{err}</p>}
        <TextField value={name} onChange={(v) => { setName(v); setErr(''); }} label="Naam (Name)" placeholder="Customer ka naam" autoFocus />
        <TextField value={phone} onChange={setPhone} label="Phone (optional)" placeholder="0300-1234567" />
        <TextField value={note} onChange={setNote} label="Note (optional)" placeholder="Koi remark" multiline />
      </div>
    </Modal>
  );
}

function CustomerDetail({
  customer,
  credits,
  onBack,
  onAddCredit,
  onDeleteCredit,
  onEditCustomer,
  onDeleteCustomer,
}: {
  customer: Customer;
  credits: ReturnType<typeof useStore>['credits'];
  onBack: () => void;
  onAddCredit: (input: { customerId: string; amount: number; date: string; note: string }) => void;
  onDeleteCredit: (id: string) => void;
  onEditCustomer: (id: string, name: string, phone?: string, note?: string) => void;
  onDeleteCustomer: (id: string) => void;
}) {
  const balance = useMemo(() => customerBalance(credits, customer.id), [credits, customer.id]);
  const entries = useMemo(
    () => credits.filter((c) => c.customerId === customer.id).sort((a, b) => b.createdAt - a.createdAt),
    [credits, customer.id]
  );

  const [addOpen, setAddOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [confirmDeleteCustomer, setConfirmDeleteCustomer] = useState(false);
  const [deleteCreditId, setDeleteCreditId] = useState<string | null>(null);
  const [creditType, setCreditType] = useState<'udhaar' | 'payment'>('udhaar');

  const handleAdd = (amount: number, date: string, note: string) => {
    const signed = creditType === 'payment' ? -amount : amount;
    // prevent over-payment (negative balance) for payment entries
    if (creditType === 'payment' && amount > balance) {
      return; // guarded in modal too
    }
    onAddCredit({ customerId: customer.id, amount: signed, date, note });
    setAddOpen(false);
  };

  return (
    <div className="px-4 pt-4 pb-4">
      <div className="flex items-center gap-3 mb-4">
        <IconButton onClick={onBack} className="!p-2 -ml-2">
          <ArrowLeft size={22} />
        </IconButton>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-extrabold text-slate-800 truncate">{customer.name}</h1>
          {customer.phone && <p className="text-sm text-slate-500 flex items-center gap-1"><Phone size={12} /> {customer.phone}</p>}
        </div>
        <IconButton onClick={() => setEditOpen(true)} className="!p-2">
          <Pencil size={18} />
        </IconButton>
        <IconButton onClick={() => setConfirmDeleteCustomer(true)} className="!p-2 text-red-500">
          <Trash2 size={18} />
        </IconButton>
      </div>

      {/* Balance card */}
      <div className={`rounded-2xl p-5 mb-4 text-white shadow-lg ${balance > 0 ? 'bg-gradient-to-br from-amber-500 to-orange-600 shadow-amber-500/20' : 'bg-gradient-to-br from-emerald-600 to-teal-700 shadow-emerald-600/20'}`}>
        <p className="text-sm opacity-90">Baqaya Udhaar</p>
        <p className="text-3xl font-extrabold mt-1">{formatPKR(Math.abs(balance))}</p>
        <p className="text-sm opacity-80 mt-1">
          {balance > 0 ? 'Customer ko dena hai' : balance < 0 ? 'Customer ne aagey diya' : 'Hisab clear hai'}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <Button variant="secondary" block onClick={() => { setCreditType('udhaar'); setAddOpen(true); }}>
          <Plus size={18} /> Udhaar
        </Button>
        <Button variant="success" block onClick={() => { setCreditType('payment'); setAddOpen(true); }} disabled={balance <= 0}>
          <TrendingDown size={18} /> Payment
        </Button>
      </div>

      {/* History */}
      <h2 className="font-bold text-slate-800 text-sm mb-3">History</h2>
      {entries.length === 0 ? (
        <EmptyState icon={Users} title="Koi entry nahi" />
      ) : (
        <div className="space-y-2">
          {entries.map((e) => (
            <div key={e.id} className="bg-white rounded-xl border border-slate-100 shadow-sm p-3.5 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${e.amount > 0 ? 'bg-amber-50 text-amber-600' : 'bg-emerald-50 text-emerald-600'}`}>
                {e.amount > 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-700 truncate">{e.note || (e.amount > 0 ? 'Udhaar' : 'Payment')}</p>
                <p className="text-xs text-slate-400">{formatDate(e.date)}</p>
              </div>
              <p className={`text-sm font-bold shrink-0 ${e.amount > 0 ? 'text-amber-600' : 'text-emerald-600'}`}>
                {e.amount > 0 ? '+' : ''}{formatPKR(e.amount)}
              </p>
              <IconButton onClick={() => setDeleteCreditId(e.id)} className="!p-1.5 text-slate-300 hover:text-red-500">
                <Trash2 size={14} />
              </IconButton>
            </div>
          ))}
        </div>
      )}

      <AddCreditModal
        open={addOpen}
        mode={creditType}
        currentBalance={balance}
        onClose={() => setAddOpen(false)}
        onSave={handleAdd}
      />

      {editOpen && (
        <AddCustomerModal
          open={editOpen}
          onClose={() => setEditOpen(false)}
          title="Customer Edit"
          initial={customer}
          onSave={(name, phone, note) => {
            onEditCustomer(customer.id, name, phone, note);
            setEditOpen(false);
          }}
        />
      )}

      <ConfirmDialog
        open={confirmDeleteCustomer}
        title="Customer delete?"
        message={`"${customer.name}" aur inki saari udhaar history delete ho jayegi. Yeh wapas nahi aayega.`}
        confirmLabel="Delete"
        onConfirm={() => {
          setConfirmDeleteCustomer(false);
          onDeleteCustomer(customer.id);
        }}
        onCancel={() => setConfirmDeleteCustomer(false)}
      />

      <ConfirmDialog
        open={!!deleteCreditId}
        title="Entry delete?"
        message="Yeh udhaar/payment entry delete ho jayegi. Continue?"
        confirmLabel="Delete"
        onConfirm={() => {
          if (deleteCreditId) onDeleteCredit(deleteCreditId);
          setDeleteCreditId(null);
        }}
        onCancel={() => setDeleteCreditId(null)}
      />
    </div>
  );
}

function AddCreditModal({
  open,
  mode,
  currentBalance,
  onClose,
  onSave,
}: {
  open: boolean;
  mode: 'udhaar' | 'payment';
  currentBalance: number;
  onClose: () => void;
  onSave: (amount: number, date: string, note: string) => void;
}) {
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(todayISO());
  const [note, setNote] = useState('');
  const [err, setErr] = useState('');

  const reset = () => {
    setAmount('');
    setDate(todayISO());
    setNote('');
    setErr('');
  };

  const submit = () => {
    const n = validateAmount(amount);
    if (n === null) {
      setErr('Sahi raqam likhein (0 se zyada)');
      return;
    }
    if (mode === 'payment' && n > currentBalance) {
      setErr(`Payment baqaya se zyada nahi ho sakti. Baqaya: ${formatPKR(currentBalance)}`);
      return;
    }
    onSave(n, date, note);
    reset();
  };

  const close = () => {
    reset();
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={close}
      title={mode === 'udhaar' ? 'Naya Udhaar' : 'Payment Receive'}
      footer={
        <div className="flex gap-3">
          <Button variant="secondary" block onClick={close}>
            Cancel
          </Button>
          <Button variant={mode === 'udhaar' ? 'primary' : 'success'} block onClick={submit}>
            Save
          </Button>
        </div>
      }
    >
      <div className="space-y-4">
        {err && <p className="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">{err}</p>}
        {mode === 'payment' && currentBalance > 0 && (
          <p className="text-sm text-amber-700 bg-amber-50 rounded-lg px-3 py-2">
            Baqaya: <strong>{formatPKR(currentBalance)}</strong>
          </p>
        )}
        <AmountInput value={amount} onChange={(v) => { setAmount(v); setErr(''); }} autoFocus label={mode === 'udhaar' ? 'Udhaar raqam' : 'Payment raqam'} />
        <DateField value={date} onChange={setDate} />
        <TextField value={note} onChange={setNote} label="Note (optional)" placeholder="Item ya remark" />
      </div>
    </Modal>
  );
}
