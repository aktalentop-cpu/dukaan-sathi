import type { AppData, Customer, CreditEntry, Transaction, Product } from '@/types';
import { uid } from './format';

const DAY = 86400000;

function isoDaysAgo(days: number): string {
  return new Date(Date.now() - days * DAY).toISOString().slice(0, 10);
}

export function buildSampleData(): AppData {
  const customers: Customer[] = [
    { id: uid(), name: 'Bilal Khan', phone: '0301-1234567', note: 'Kirana regular', createdAt: Date.now() - 30 * DAY },
    { id: uid(), name: 'Aslam Uncle', phone: '0321-7654321', note: 'Monthly settled', createdAt: Date.now() - 60 * DAY },
    { id: uid(), name: 'Saima Bibi', phone: '0333-1112222', createdAt: Date.now() - 15 * DAY },
    { id: uid(), name: 'Imran Qureshi', createdAt: Date.now() - 10 * DAY },
  ];

  const credits: CreditEntry[] = [
    { id: uid(), customerId: customers[0].id, amount: 1500, date: isoDaysAgo(5), note: 'Ataa, chawal, cheeni', createdAt: Date.now() - 5 * DAY },
    { id: uid(), customerId: customers[0].id, amount: 800, date: isoDaysAgo(2), note: 'Tel + doodh', createdAt: Date.now() - 2 * DAY },
    { id: uid(), customerId: customers[0].id, amount: -500, date: isoDaysAgo(1), note: 'Aadha payment', createdAt: Date.now() - 1 * DAY },
    { id: uid(), customerId: customers[1].id, amount: 3000, date: isoDaysAgo(12), note: 'Monthly udhaar', createdAt: Date.now() - 12 * DAY },
    { id: uid(), customerId: customers[1].id, amount: -3000, date: isoDaysAgo(8), note: 'Pooraa jama', createdAt: Date.now() - 8 * DAY },
    { id: uid(), customerId: customers[2].id, amount: 600, date: isoDaysAgo(3), note: 'Sabzi', createdAt: Date.now() - 3 * DAY },
    { id: uid(), customerId: customers[3].id, amount: 1200, date: isoDaysAgo(1), note: 'Cigarettes + biscuit', createdAt: Date.now() - 1 * DAY },
  ];

  const transactions: Transaction[] = [
    { id: uid(), type: 'sale', amount: 2400, date: isoDaysAgo(0), note: 'Subah ki sale', createdAt: Date.now() - 2 * 3600000 },
    { id: uid(), type: 'sale', amount: 1800, date: isoDaysAgo(0), note: 'Dopehar', createdAt: Date.now() - 1 * 3600000 },
    { id: uid(), type: 'expense', amount: 500, date: isoDaysAgo(0), note: 'Electricity bill', createdAt: Date.now() - 1 * 3600000 },
    { id: uid(), type: 'sale', amount: 3200, date: isoDaysAgo(1), note: 'Sunday sale', createdAt: Date.now() - DAY },
    { id: uid(), type: 'sale', amount: 1500, date: isoDaysAgo(1), note: 'Raat', createdAt: Date.now() - DAY },
    { id: uid(), type: 'expense', amount: 1200, date: isoDaysAgo(1), note: 'Generator petrol', createdAt: Date.now() - DAY },
    { id: uid(), type: 'sale', amount: 2800, date: isoDaysAgo(2), note: '', createdAt: Date.now() - 2 * DAY },
    { id: uid(), type: 'sale', amount: 2100, date: isoDaysAgo(3), note: 'Eid stock sale', createdAt: Date.now() - 3 * DAY },
    { id: uid(), type: 'expense', amount: 8000, date: isoDaysAgo(4), note: 'Wholesale purchase', createdAt: Date.now() - 4 * DAY },
    { id: uid(), type: 'sale', amount: 1900, date: isoDaysAgo(5), note: '', createdAt: Date.now() - 5 * DAY },
    { id: uid(), type: 'sale', amount: 2600, date: isoDaysAgo(8), note: '', createdAt: Date.now() - 8 * DAY },
    { id: uid(), type: 'sale', amount: 1700, date: isoDaysAgo(12), note: '', createdAt: Date.now() - 12 * DAY },
  ];

  const products: Product[] = [
    { id: uid(), name: 'Ataa (10kg)', purchasePrice: 1100, sellingPrice: 1250, quantity: 8, lowStockThreshold: 3, createdAt: Date.now() - 20 * DAY },
    { id: uid(), name: 'Cheeni (1kg)', purchasePrice: 130, sellingPrice: 150, quantity: 25, lowStockThreshold: 5, createdAt: Date.now() - 20 * DAY },
    { id: uid(), name: 'Chawal (1kg)', purchasePrice: 220, sellingPrice: 260, quantity: 4, lowStockThreshold: 5, createdAt: Date.now() - 18 * DAY },
    { id: uid(), name: 'Tel (5L)', purchasePrice: 2400, sellingPrice: 2700, quantity: 2, lowStockThreshold: 2, createdAt: Date.now() - 15 * DAY },
    { id: uid(), name: 'Doodh pack', purchasePrice: 240, sellingPrice: 280, quantity: 0, lowStockThreshold: 10, createdAt: Date.now() - 10 * DAY },
  ];

  return { customers, credits, transactions, products, seeded: true };
}
