import { useEffect } from 'react';
import { App } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';

/**
 * Sets up native Android integration when running inside Capacitor:
 *  - Status bar styled to match the app's emerald header
 *  - Hardware back button navigates back / exits gracefully
 *
 * On web (no Capacitor runtime) these calls are no-ops, so the
 * existing browser-only behaviour is unchanged.
 */
export function useNativeAndroid() {
  useEffect(() => {
    // Status bar — only applies on device, harmless on web
    StatusBar.setStyle({ style: Style.Dark }).catch(() => {});
    StatusBar.setBackgroundColor({ color: '#059669' }).catch(() => {});

    // Hardware back button
    const handle = App.addListener('backButton', ({ canGoBack }) => {
      if (canGoBack) {
        window.history.back();
      } else {
        App.exitApp();
      }
    });

    return () => {
      handle.then((h) => h.remove());
    };
  }, []);
}
