import { useState } from 'react';
import { StoreProvider } from '@/lib/store';
import { useNativeAndroid } from '@/lib/native';
import { BottomNav } from '@/components/BottomNav';
import { DataLossBanner } from '@/components/DataSettings';
import { Dashboard } from '@/screens/Dashboard';
import { UdhaarScreen } from '@/screens/Udhaar';
import { SalesScreen } from '@/screens/Sales';
import { StockScreen } from '@/screens/Stock';
import { ReportsScreen } from '@/screens/Reports';
import type { Screen } from '@/types';

function AppShell() {
  const [screen, setScreen] = useState<Screen>('dashboard');
  const [bannerDismissed, setBannerDismissed] = useState(false);
  useNativeAndroid();

  const navigate = (s: Screen) => {
    setScreen(s);
    window.scrollTo({ top: 0 });
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Mobile-first container */}
      <div className="max-w-md mx-auto bg-slate-50 min-h-screen relative">
        {!bannerDismissed && (
          <DataLossBanner onDismiss={() => setBannerDismissed(true)} />
        )}

        <main className="pb-24">
          {screen === 'dashboard' && <Dashboard onNavigate={navigate} onQuickAdd={(s) => navigate(s)} />}
          {screen === 'udhaar' && <UdhaarScreen />}
          {screen === 'sales' && <SalesScreen />}
          {screen === 'stock' && <StockScreen />}
          {screen === 'reports' && <ReportsScreen onNavigate={navigate} />}
        </main>

        <BottomNav active={screen} onChange={navigate} />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <AppShell />
    </StoreProvider>
  );
}
