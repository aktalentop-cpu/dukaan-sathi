import { useState, useEffect, useRef } from 'react';
import { Search, X } from 'lucide-react';

export function SearchBar({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div className="relative">
      <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder ?? 'Search...'}
        className="w-full pl-11 pr-10 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
      />
      {value && (
        <button
          onClick={() => onChange('')}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
          aria-label="Clear search"
        >
          <X size={18} />
        </button>
      )}
    </div>
  );
}

interface AmountInputProps {
  value: string;
  onChange: (v: string) => void;
  label?: string;
  autoFocus?: boolean;
}

export function AmountInput({ value, onChange, label = 'Raqam (Amount)', autoFocus }: AmountInputProps) {
  return (
    <label className="block">
      <span className="block text-sm font-semibold text-slate-700 mb-1.5">{label}</span>
      <div className="relative">
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-semibold text-base pointer-events-none">Rs.</span>
        <input
          type="number"
          inputMode="decimal"
          min="0"
          step="any"
          value={value}
          autoFocus={autoFocus}
          onChange={(e) => onChange(e.target.value)}
          placeholder="0"
          className="w-full pl-12 pr-4 py-3.5 rounded-xl border border-slate-200 bg-white text-lg font-semibold text-slate-800 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
        />
      </div>
    </label>
  );
}

interface TextFieldProps {
  value: string;
  onChange: (v: string) => void;
  label: string;
  placeholder?: string;
  autoFocus?: boolean;
  multiline?: boolean;
}

export function TextField({ value, onChange, label, placeholder, autoFocus, multiline }: TextFieldProps) {
  return (
    <label className="block">
      <span className="block text-sm font-semibold text-slate-700 mb-1.5">{label}</span>
      {multiline ? (
        <textarea
          value={value}
          autoFocus={autoFocus}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          rows={2}
          className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent resize-none"
        />
      ) : (
        <input
          type="text"
          value={value}
          autoFocus={autoFocus}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
        />
      )}
    </label>
  );
}

interface DateFieldProps {
  value: string;
  onChange: (v: string) => void;
  label?: string;
}

export function DateField({ value, onChange, label = 'Date' }: DateFieldProps) {
  const ref = useRef<HTMLInputElement>(null);
  return (
    <label className="block">
      <span className="block text-sm font-semibold text-slate-700 mb-1.5">{label}</span>
      <input
        ref={ref}
        type="date"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
      />
    </label>
  );
}

// Validates a positive amount string. Returns null if valid, else error message.
export function validateAmount(raw: string): number | null {
  const n = parseFloat(raw);
  if (raw.trim() === '' || isNaN(n)) return null;
  if (n <= 0) return null;
  return Math.round(n * 100) / 100;
}

// Inline toast for quick feedback
export function useToast() {
  const [msg, setMsg] = useState<string | null>(null);
  useEffect(() => {
    if (!msg) return;
    const t = setTimeout(() => setMsg(null), 2200);
    return () => clearTimeout(t);
  }, [msg]);
  return { msg, show: setMsg };
}
