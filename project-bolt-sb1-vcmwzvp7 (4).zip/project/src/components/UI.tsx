import type { ReactNode } from 'react';
import type { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string;
  icon: LucideIcon;
  tone?: 'emerald' | 'red' | 'blue' | 'amber' | 'slate';
  sub?: string;
}

const tones: Record<string, { bg: string; fg: string; ring: string }> = {
  emerald: { bg: 'bg-emerald-50', fg: 'text-emerald-600', ring: 'ring-emerald-100' },
  red: { bg: 'bg-red-50', fg: 'text-red-600', ring: 'ring-red-100' },
  blue: { bg: 'bg-blue-50', fg: 'text-blue-600', ring: 'ring-blue-100' },
  amber: { bg: 'bg-amber-50', fg: 'text-amber-600', ring: 'ring-amber-100' },
  slate: { bg: 'bg-slate-100', fg: 'text-slate-600', ring: 'ring-slate-200' },
};

export function StatCard({ label, value, icon: Icon, tone = 'emerald', sub }: StatCardProps) {
  const t = tones[tone];
  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
      <div className="flex items-start justify-between">
        <div className="min-w-0">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{label}</p>
          <p className="text-xl font-bold text-slate-800 mt-1 truncate">{value}</p>
          {sub && <p className="text-xs text-slate-400 mt-0.5">{sub}</p>}
        </div>
        <div className={`shrink-0 w-9 h-9 rounded-xl ${t.bg} ${t.fg} flex items-center justify-center ring-4 ${t.ring}`}>
          <Icon size={18} />
        </div>
      </div>
    </div>
  );
}

export function EmptyState({ icon: Icon, title, hint }: { icon: LucideIcon; title: string; hint?: string }) {
  return (
    <div className="text-center py-12 px-6">
      <div className="w-14 h-14 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
        <Icon size={26} />
      </div>
      <p className="mt-4 text-slate-600 font-semibold">{title}</p>
      {hint && <p className="mt-1 text-sm text-slate-400">{hint}</p>}
    </div>
  );
}

export function SectionHeader({ title, action }: { title: string; action?: ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-3">
      <h2 className="text-base font-bold text-slate-800">{title}</h2>
      {action}
    </div>
  );
}
