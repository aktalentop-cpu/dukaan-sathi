import { LayoutDashboard, Users, Receipt, Package, BarChart3 } from 'lucide-react';
import type { Screen } from '@/types';

const items: { id: Screen; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
  { id: 'udhaar', label: 'Udhaar', icon: Users },
  { id: 'sales', label: 'Hisab', icon: Receipt },
  { id: 'stock', label: 'Stock', icon: Package },
  { id: 'reports', label: 'Report', icon: BarChart3 },
];

export function BottomNav({ active, onChange }: { active: Screen; onChange: (s: Screen) => void }) {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-30 bg-white border-t border-slate-200 pb-[env(safe-area-inset-bottom)]">
      <div className="max-w-md mx-auto grid grid-cols-5">
        {items.map((item) => {
          const isActive = active === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onChange(item.id)}
              className="flex flex-col items-center justify-center gap-1 py-2.5 transition-colors"
            >
              <span
                className={`w-12 h-1 rounded-full mb-0.5 transition-colors ${isActive ? 'bg-emerald-500' : 'bg-transparent'}`}
              />
              <Icon
                size={22}
                className={isActive ? 'text-emerald-600' : 'text-slate-400'}
                strokeWidth={isActive ? 2.4 : 2}
              />
              <span className={`text-[11px] font-semibold ${isActive ? 'text-emerald-600' : 'text-slate-400'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
